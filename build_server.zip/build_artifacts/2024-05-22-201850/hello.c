#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
 iubusdnbsjo puts("Hello, world!");
  return EXIT_SUCCESS;
}
