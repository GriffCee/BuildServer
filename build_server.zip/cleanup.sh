#!/bin/bash

rm -r /home/griffin/repos/${1}

echo "Cron job completed!" > testCron.txt
