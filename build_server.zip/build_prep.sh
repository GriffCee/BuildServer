#!/bin/bash

cd /home/griffin/repos/raw_data_repo
cp -R /home/griffin/repos/raw_data_repo/${1} ..

cd ..
